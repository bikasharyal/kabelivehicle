<?php
// Current system uses PHPMailer to send mails.

// This file uses "sendmail" library to send email..
// Therefore, this file don't include materials for PHPMailer.

mail('sity1c216059@islingtoncollege.edu.np','test subject','hello there','From: vcasharyal@gmail.com');

?>

